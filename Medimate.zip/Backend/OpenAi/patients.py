from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample dictionary mapping symptoms to potential medical conditions
symptom_conditions = {
    'fever': ['common cold', 'flu'],
    'cough': ['common cold', 'flu', 'bronchitis'],
    'headache': ['migraine', 'tension headache']
}

# Sample dictionary mapping medical conditions to doctors
condition_doctors = {
    'common cold': 'Dr. Smith',
    'flu': 'Dr. Johnson',
    'bronchitis': 'Dr. Lee',
    'migraine': 'Dr. Brown',
    'tension headache': 'Dr. Davis'
}
@app.route('/')

@app.route('/assign_doctor', methods=['POST'])
def assign_doctor():
    data = request.get_json()
    symptoms = data['symptoms']

    # Perform symptom checking logic to identify potential medical conditions
    matched_conditions = []
    for symptom in symptoms:
        if symptom in symptom_conditions:
            matched_conditions.extend(symptom_conditions[symptom])

    # Deduplicate and prioritize medical conditions
    unique_conditions = list(set(matched_conditions))

    # Assign doctor based on prioritized medical conditions
    assigned_doctors = []
    for condition in unique_conditions:
        if condition in condition_doctors:
            assigned_doctors.append(condition_doctors[condition])

    return jsonify({'assigned_doctors': assigned_doctors})

if __name__ == '__main__':
    app.run(debug=True)