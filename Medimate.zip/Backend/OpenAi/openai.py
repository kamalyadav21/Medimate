from openai import OpenAI

client = OpenAI()