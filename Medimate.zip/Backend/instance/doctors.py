
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
import os


app = Flask(__name__, template_folder='templates')
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'hospital.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

@app.route('/')
def index():
    return render_template('index1.html')


class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)

@app.route('/doctors', methods=['POST'])
def create_doctor():
    data = request.get_json()
    new_doctor = Doctor(name=data['name'], specialization=data['specialization'])
    db.session.add(new_doctor)
    db.session.commit()
    return jsonify({'message': 'Doctor created'}), 201

@app.route('/doctors', methods=['GET'])
def get_doctors():
    doctors = Doctor.query.all()
    return jsonify([{'id': doctor.id, 'name': doctor.name, 'specialization': doctor.specialization} for doctor in doctors])

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)